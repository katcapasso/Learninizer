const express = require('express');
const axios = require('axios');
const dotenv = require('dotenv');
const path = require('path'); // Required to serve the frontend HTML file

dotenv.config();

const app = express();
const port = 3000;

// Middleware to parse JSON and serve static files
app.use(express.json());
app.use(express.static('public')); // Serve static assets (HTML, CSS, JS, etc.)

// Define the /generate-text route
app.post('/generate-text', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
    }

    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: 'gpt-3.5-turbo',
                messages: [{ role: 'user', content: prompt }],
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
                },
            }
        );

        const generatedText = response.data.choices[0].message.content;
        res.json({ generatedText });
    } catch (error) {
        console.error('Error generating text:', error.response?.data || error.message);
        res.status(500).json({ error: 'Failed to generate text' });
    }
});

// Code 3: Route to serve the index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});




